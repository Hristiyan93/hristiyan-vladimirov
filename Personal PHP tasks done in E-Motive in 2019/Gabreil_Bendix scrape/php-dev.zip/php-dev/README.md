# PHP files task

This task is used to show basic php knowlegde and operations with files.

## Tasks:

1. Create simple scripts to extract only simple products with price below 10 using php-files-task.csv. Save the results in results.csv.
2. Create simple scripts to extract only bundle products using php-files-task.json. Save the results in results.json.

Note: Please use core php functions.
