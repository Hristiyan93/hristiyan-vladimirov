<div id="slideshow">
            <div class="fullwidthbanner-container" style="overflow: visible;">
                <div class="revolution-slider rev_slider revslider-initialised tp-simpleresponsive" style="height: 646px; overflow: hidden; margin-top: 0px; margin-bottom: 0px;" id="revslider-246" data-slideactive="rs-14">
                    <ul class="tp-revslider-mainul" style="visibility: visible; display: block; overflow: hidden; width: 1725px; height: 100%; max-height: 700px; left: 0px;">	<!-- SLIDE  -->
                    
                    	<li data-index="rs-14" data-transition="zoomout" data-slotamount="7" data-hideafterloop="0" 
                    			data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="1000" 
                    			data-thumb="/images/slide/bg1.jpg" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="" class="tp-revslider-slidesli active-revslide" style="width: 100%; height: 100%; overflow: hidden; z-index: 20; visibility: inherit; opacity: 1; background-color: rgba(255, 255, 255, 0);">
							<!-- MAIN IMAGE -->
							<div class="slotholder" style="position: absolute; top: 0px; left: 0px; z-index: 0; width: 100%; height: 100%; backface-visibility: hidden; transform: translate3d(0px, 0px, 0px); visibility: inherit; opacity: 1;"><!--Runtime Modification - Img tag is Still Available for SEO Goals in Source - <img src="/images/slide/bg1.jpg" alt="" title="Slider1" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg defaultimg" data-no-retina="">--><div class="tp-bgimg defaultimg" style="width: 100%; height: 100%; opacity: 1; visibility: inherit; z-index: 20; background-image: url(/images/slide/bg1.jpg); background-color: rgba(0, 0, 0, 0); background-size: cover; background-position: center top; background-repeat: no-repeat;" src="/images/slide/bg1.jpg"></div></div>
							<!-- LAYERS -->

							<!-- LAYER NR. 1 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 961px; top: 16px; z-index: 5;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption   tp-resizeme" id="slide-14-layer-1" data-x="576" data-y="16" data-width="['none','none','none','none']" data-height="['none','none','none','none']" data-transform_idle="o:1;" data-transform_in="x:left;s:1500;e:Power3.easeInOut;" data-transform_out="x:50px;opacity:0;s:1500;s:1500;" data-start="500" data-responsive_offset="on" style="z-index: 5; visibility: inherit; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><img src="/images/slide/girl.png" alt="" data-ww="650px" data-hh="637px" data-no-retina="" style="width: 650px; height: 637px; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px;"> </div></div></div></div>

							<!-- LAYER NR. 2 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 412px; top: 359px; z-index: 6;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption   tp-resizeme" id="slide-14-layer-2" data-x="27" data-y="359" data-width="['none','none','none','none']" data-height="['none','none','none','none']" data-transform_idle="o:1;" data-transform_in="x:right;s:1500;e:Power3.easeInOut;" data-transform_out="x:-50px;opacity:0;s:1500;s:1500;" data-start="800" data-responsive_offset="on" style="z-index: 6; visibility: inherit; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><img src="/images/slide/island.png" alt="" data-ww="267px" data-hh="187px" data-no-retina="" style="width: 267px; height: 187px; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px;"> </div></div></div></div>

							<!-- LAYER NR. 3 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 651px; top: 479px; z-index: 7;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption   tp-resizeme" id="slide-14-layer-3" data-x="266" data-y="479" data-width="['none','none','none','none']" data-height="['none','none','none','none']" data-transform_idle="o:1;" data-transform_in="y:bottom;s:1500;e:Power3.easeInOut;" data-transform_out="y:-50px;opacity:0;s:300;s:300;" data-start="1100" data-responsive_offset="on" style="z-index: 7; visibility: inherit; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><img src="/images/slide/ballon.png" alt="" data-ww="25px" data-hh="auto" data-no-retina="" style="width: 25px; height: 34px; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px;"> </div></div></div></div>

							<!-- LAYER NR. 4 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 769px; top: 441px; z-index: 8;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption   tp-resizeme" id="slide-14-layer-4" data-x="384" data-y="441" data-width="['none','none','none','none']" data-height="['none','none','none','none']" data-transform_idle="o:1;" data-transform_in="x:left;s:1500;e:Power3.easeInOut;" data-transform_out="y:-50px;opacity:0;s:300;s:300;" data-start="1400" data-responsive_offset="on" style="z-index: 8; visibility: inherit; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><img src="/images/slide/plane1.png" alt="" data-ww="262px" data-hh="100px" data-no-retina="" style="width: 262px; height: 100px; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px;"> </div></div></div></div>

							<!-- LAYER NR. 5 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 410px; top: 181px; z-index: 9;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption large_bold_white_med_2   tp-resizeme" id="slide-14-layer-5" data-x="25" data-y="181" data-width="['auto']" data-height="['auto']" data-transform_idle="o:1;" data-transform_in="y:bottom;s:1500;e:Power3.easeInOut;" data-transform_out="x:50px;opacity:0;s:300;s:300;" data-start="1700" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 9; white-space: nowrap; color: rgb(255, 255, 255); font-family: Arial; border-color: rgb(255, 214, 88); visibility: inherit; transition: none; line-height: 28px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 500; font-size: 30px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><p class="caption-big-title" style="transition: none; line-height: 28px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 500; font-size: 30px;"><?php echo $this->translate('Let\'s Discover the world together!')?></p> </div></div></div></div>

							<!-- LAYER NR. 6 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 407px; top: 230px; z-index: 10;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption   tp-resizeme" id="slide-14-layer-6" data-x="22" data-y="230" data-width="['none','none','none','none']" data-height="['none','none','none','none']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:1500;e:Power3.easeInOut;" data-transform_out="x:-50px;opacity:0;s:1500;s:1500;" data-start="2000" data-responsive_offset="on" style="z-index: 10; visibility: inherit; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><img src="/images/slide/pleane.png" alt="" data-ww="auto" data-hh="auto" data-no-retina="" style="width: 43px; height: 32px; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px;"> </div></div></div></div>

							<!-- LAYER NR. 7 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 408px; top: 273px; z-index: 11;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption   tp-resizeme" id="slide-14-layer-7" data-x="23" data-y="273" data-width="['none','none','none','none']" data-height="['none','none','none','none']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:1500;e:Power3.easeInOut;" data-transform_out="x:-50px;opacity:0;s:1300;s:1300;" data-start="2300" data-responsive_offset="on" style="z-index: 11; visibility: inherit; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;"><img src="/images/slide/buil.png" alt="" data-ww="auto" data-hh="auto" data-no-retina="" style="width: 43px; height: 32px; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px;"> </div></div></div></div>

							<!-- LAYER NR. 8 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 403px; top: 317px; z-index: 12;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption   tp-resizeme" id="slide-14-layer-8" data-x="18" data-y="317" data-width="['none','none','none','none']" data-height="['none','none','none','none']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:1300;e:Power3.easeInOut;" data-transform_out="x:-50px;opacity:0;s:1100;s:1100;" data-start="2600" data-responsive_offset="on" style="z-index: 12; visibility: inherit; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform-origin: 50% 50% 0px; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);"><img src="/images/slide/watch1.png" alt="" data-ww="auto" data-hh="auto" data-no-retina="" style="width: 43px; height: 32px; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px;"> </div></div></div></div>

							<!-- LAYER NR. 9 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 403px; top: 354px; z-index: 13;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption   tp-resizeme" id="slide-14-layer-9" data-x="18" data-y="354" data-width="['none','none','none','none']" data-height="['none','none','none','none']" data-transform_idle="o:1;" data-transform_in="x:-50px;opacity:0;s:1500;e:Power3.easeInOut;" data-transform_out="x:-50px;opacity:0;s:900;s:900;" data-start="2900" data-responsive_offset="on" style="z-index: 13; visibility: inherit; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px; white-space: nowrap; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform-origin: 50% 50% 0px; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);"><img src="/images/slide/man.png" alt="" data-ww="auto" data-hh="auto" data-no-retina="" style="width: 43px; height: 31px; transition: none; line-height: 0px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 12px;"> </div></div></div></div>

							<!-- LAYER NR. 10 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 457px; top: 230px; z-index: 14;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption large_bold_white_med   tp-resizeme" id="slide-14-layer-10" data-x="72" data-y="230" data-width="['auto']" data-height="['auto']" data-transform_idle="o:1;" data-transform_in="y:top;s:1500;e:Power3.easeInOut;" data-transform_out="y:-50px;opacity:0;s:300;s:300;" data-start="3200" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 14; white-space: nowrap; color: rgb(255, 255, 255); font-family: Arial; border-color: rgb(255, 214, 88); visibility: inherit; transition: none; line-height: 28px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 25px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform-origin: 50% 50% 0px; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);"><span class="caption-medium-title" style="transition: none; line-height: 28px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 25px;"><?php echo $this->translate('Over 500 Airlines')?></span> </div></div></div></div>

							<!-- LAYER NR. 11 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 458px; top: 274px; z-index: 15;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption large_bold_white_med   tp-resizeme" id="slide-14-layer-11" data-x="73" data-y="274" data-width="['auto']" data-height="['auto']" data-transform_idle="o:1;" data-transform_in="y:top;s:1500;e:Power3.easeInOut;" data-transform_out="x:-50px;opacity:0;s:300;s:300;" data-start="3500" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 15; white-space: nowrap; color: rgb(255, 255, 255); font-family: Arial; border-color: rgb(255, 214, 88); visibility: inherit; transition: none; line-height: 28px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 25px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform-origin: 50% 50% 0px; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);"><span class="caption-medium-title" style="transition: none; line-height: 28px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 25px;"><?php echo $this->translate('More than 13,000 Places')?></span> </div></div></div></div>

							<!-- LAYER NR. 12 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 458px; top: 318px; z-index: 16;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption large_bold_white_med   tp-resizeme" id="slide-14-layer-12" data-x="73" data-y="318" data-width="['auto']" data-height="['auto']" data-transform_idle="o:1;" data-transform_in="y:top;s:1500;e:Power3.easeInOut;" data-transform_out="x:-50px;opacity:0;s:300;s:300;" data-start="3800" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 16; white-space: nowrap; color: rgb(255, 255, 255); font-family: Arial; border-color: rgb(255, 214, 88); visibility: inherit; transition: none; line-height: 28px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 25px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform-origin: 50% 50% 0px; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);"><span class="caption-medium-title" style="transition: none; line-height: 28px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 25px;"><?php echo $this->translate('Best Price Guarantee')?></span> </div></div></div></div>

							<!-- LAYER NR. 13 -->
							<div class="tp-parallax-wrap" style="position: absolute; visibility: visible; left: 460px; top: 357px; z-index: 17;"><div class="tp-loop-wrap" style="position:absolute;"><div class="tp-mask-wrap" style="position: absolute; overflow: visible; height: auto; width: auto;"><div class="tp-caption large_bold_white_med   tp-resizeme" id="slide-14-layer-13" data-x="75" data-y="357" data-width="['auto']" data-height="['auto']" data-transform_idle="o:1;" data-transform_in="y:top;s:1500;e:Power3.easeInOut;" data-transform_out="x:-50px;opacity:0;s:300;s:300;" data-start="4100" data-splitin="none" data-splitout="none" data-responsive_offset="on" style="z-index: 17; white-space: nowrap; color: rgb(255, 255, 255); font-family: Arial; border-color: rgb(255, 214, 88); visibility: inherit; transition: none; line-height: 28px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 25px; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform-origin: 50% 50% 0px; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);"><span class="caption-medium-title" style="transition: none; line-height: 28px; border-width: 0px; margin: 0px; padding: 0px; letter-spacing: 0px; font-weight: 400; font-size: 25px;"><?php echo $this->translate('Customer Care')?></span> </div></div></div></div>

						</li>
                    	
					</ul>
                <div class="tp-loader spinner4" style="display: none;"><div class="dot1"></div><div class="dot2"></div><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div><div class="tp-bannertimer" style="visibility: visible; width: 0%; transform: translate3d(0px, 0px, 0px);"></div><div class="tp-leftarrow tparrows default  noSwipe" style="top: 50%; transform: matrix(1, 0, 0, 1, 20, -20); left: 0px;"></div><div class="tp-rightarrow tparrows default  noSwipe" style="top: 50%; transform: matrix(1, 0, 0, 1, -60, -20); left: 100%;"></div></div>
            </div>
        </div>


        <section id="content">
            <div class="search-box-wrapper">
                <div class="search-box container">
                    <div class="search-tab-content">
                        <div class="tab-pane fade active in" id="flights-tab">
                            <form action="/search" method="post">
                                <div class="row">
                                    <div class="col-md-4">
                                        <h4 class="title"><?php echo $this->translate('Where')?></h4>
                                        <div class="form-group">
                                            <label><?php echo $this->translate('Leaving From')?></label>
                                            <?php echo $this->formText('search[from]', null, array(
                                                'class' => 'input-text full-width autocomplete',
                                                'placeholder' => $this->translate('city, distirct or specific airpot')
                                            ))?>
                                        </div>
                                        <div class="form-group">
                                            <label><?php echo $this->translate('Going To')?></label>
                                            <?php echo $this->formText('search[to]', null, array(
                                                'class' => 'input-text full-width autocomplete',
                                                'placeholder' => $this->translate('city, distirct or specific airpot')
                                            ))?>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <h4 class="title"><?php echo $this->translate('When')?></h4>
                                        <label><?php echo $this->translate('Departing On')?></label>
                                        <div class="form-group row">
                                            <div class="col-xs-6">
                                                <div class="datepicker-wrap">
                                                	<?php echo $this->formText('search[departure]', null, array(
                                                	    'class' => "input-text full-width",
                                                	    'placeholder' => "mm/dd/yy"
                                                	))?>
                                                </div>
                                            </div>
                                            <div class="col-xs-6">
                                                <div class="selector">
                                                	<?php echo $this->formSelect('search[departure-time]', null, array('class' => 'full-width'), array(
                                                	    $this->translate('anytime'), $this->translate('morning')
                                                	))?>
                                                </div>
                                            </div>
                                        </div>
                                        <label><?php echo $this->translate('Arriving On')?></label>
                                        <div class="form-group row">
                                            <div class="col-xs-6">
                                                <div class="datepicker-wrap">
                                                	<?php echo $this->formText('search[arrival]', null, array(
                                                	    'class' => "input-text full-width",
                                                	    'placeholder' => "mm/dd/yy"
                                                	))?>
                                                </div>
                                            </div>
                                            <div class="col-xs-6">
                                                <div class="selector">
                                                    <?php echo $this->formSelect('search[arrival-time]', null, array('class' => 'full-width'), array(
                                                	    $this->translate('anytime'), $this->translate('morning')
                                                	))?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <h4 class="title"><?php echo $this->translate('Who')?></h4>
                                        <div class="form-group row">
                                            <div class="col-xs-3">
                                                <label><?php echo $this->translate('Adults')?></label>
                                                <div class="selector">
                                                	<?php echo $this->formSelect('search[adults]', null, array('class' => 'full-width'), range(1,5))?>
                                                </div>
                                            </div>
                                            <div class="col-xs-3">
                                                <label><?php echo $this->translate('Kids')?></label>
                                                <div class="selector">
                                                    <?php echo $this->formSelect('search[kids]', null, array('class' => 'full-width'), range(0,5))?>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <div class="form-group row">
                                            <div class="col-xs-3">
                                                <label><?php echo $this->translate('Infants')?></label>
                                                <div class="selector">
                                                    <?php echo $this->formSelect('search[infants]', null, array('class' => 'full-width'), range(0,5))?>
                                                </div>
                                            </div>
                                            <div class="col-xs-6 pull-right">
                                                <label>&nbsp;</label>
                                                <button class="full-width icon-check"><?php echo $this->translate('SERACH NOW')?></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <div class="container">
                    <h2><?php echo $this->translate('Featured Flight Deals')?></h2>
                    <div class="image-box style11 block">
                        <div class="row">
                        	<?php for($i=0;$i<3;$i++):?>
                            <div class="col-sm-4">
                                <article class="box">
                                    <figure class="animated" data-animation-type="fadeInDown">
                                        <a href="<?php echo $this->url(array('flightId'=>$this->routes[$i]['id']), 'flight', true)?>"><img src="/images/assets/big0<?php echo ($i+1)?>.png"></a>
                                        <figcaption>
                                            <h3 class="caption-title"><?php echo $this->routes[$i]['dstCity']?></h3>
                                            <span><?php echo $this->routes[$i]['airline']?></span>
                                        </figcaption>
                                    </figure>
                                    <div class="details">
                                        <span class="price">
                                            <small><?php echo $this->translate('From')?></small><?php echo $this->price($this->routes[$i]['price'])?>
                                        </span>
                                        <div class="icon-box style11">
                                            <div class="icon-wrapper">
                                                <i class="soap-icon-plane-right takeoff-effect circle"></i>
                                            </div>
                                            <div class="details">
                                                <h4 class="box-title"><?php echo $this->routes[$i]['srcCity'] . ' ' . $this->translate('to') . ' ' . $this->routes[$i]['dstCity']?>
                                                <small><?php echo $this->translate('Oneway flight')?></small></h4>
                                            </div>
                                        </div>
                                    </div>
                                </article>
                            </div>
                            <?php endfor;?>
                            
                        </div>
                    </div>
                    
                    <h2><?php echo $this->translate('Cheap Flights')?></h2>
                    <div class="image-carousel style2 block" data-animation="slide" data-item-width="270" data-item-margin="30">
                        <ul class="slides image-box listing-style2 flight">
                        	<?php for($i=0;$i<5;$i++):?>
                            <li>
                                <article class="box">
                                    <figure>
                                        <span><img src="/images/assets/destinations0<?php echo ($i+1)?>.jpg" alt="" width="270" height="160" /></span>
                                    </figure>
                                    <div class="details">
                                        <a title="View all" href="<?php echo $this->url(array('flightId'=>$this->routes[$i]['id']), 'flight', true)?>" class="pull-right button btn-mini uppercase"><?php echo $this->translate('select')?></a>
                                        <h4 class="box-title"><?php echo $this->routes[$i]['dstCity']?></h4>
                                        <label class="price-wrapper">
                                            <span class="price-per-unit"><?php echo $this->price($this->routes[$i]['price'])?></span><?php echo $this->translate('oneway')?>
                                        </label>
                                    </div>
                                </article>
                            </li>
                            <?php endfor;?>
                        </ul>
                    </div>

                    <div class="row">
                        <div class="col-md-4">
                            <h2><?php echo $this->translate('Before you Fly')?></h2>
                            <div class="toggle-container with-image block" id="accordion3" data-image-animation-type="fadeIn" data-image-animation-duration="2">
                                <div class="panel style1">
                                    <img src="/images/assets/before-fly.jpg" alt="" />
                                    <h4 class="panel-title">
                                        <a href="#acc7" data-toggle="collapse" data-parent="#accordion3"><?php echo $this->translate('Book your Bags in Advance')?></a>
                                    </h4>
                                    <div class="panel-collapse collapse in" id="acc7">
                                        <div class="panel-content">
                                            <p><?php echo $this->translate('The number of bags, the charges and allowable dimensions may vary depending on your flight, the fare and the class in which you are travelling.')?></p>
                                        </div><!-- end content -->
                                    </div>
                                </div>
                                
                                <div class="panel style1">
                                    <img src="/images/assets/special-meals.png" alt="" />
                                    <h4 class="panel-title">
                                        <a class="collapsed" href="#acc8" data-toggle="collapse" data-parent="#accordion3"><?php echo $this->translate('Special Meal Requests')?></a>
                                    </h4>
                                    <div class="panel-collapse collapse" id="acc8">
                                        <div class="panel-content">
                                            <p><?php echo $this->translate('Whether you would like a meal for your little ones or a special meal to meet your dietary requirements we will do our best to supply your preferred choice.')?></p>
                                        </div><!-- end content -->
                                    </div>
                                </div>
                                
                                <div class="panel style1">
                                    <img src="/images/assets/flight-status.jpg" alt="" />
                                    <h4 class="panel-title">
                                        <a class="collapsed" href="#acc9" data-toggle="collapse" data-parent="#accordion3"><?php echo $this->translate('Check your Flight Status')?></a>
                                    </h4>
                                    <div class="panel-collapse collapse" id="acc9">
                                        <div class="panel-content">
                                            <p><?php echo $this->translate('There are many factors that can affect a flight while it\'s in the air. Weather, air traffic control directives, congestion on the taxi-ways and more.')?></p>
                                        </div><!-- end content -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <h2><?php echo $this->translate('Top Flight Routes')?></h2>
                            <div class="flight-routes image-box style13 block">
                            	<?php for($i=0;$i<5;$i++):?>
                                <div class="box">
                                    <figure>
                                        <a href="<?php echo $this->url(array('flightId'=>$this->routes[$i]['id']), 'booking', true)?>"><img src="<?php echo $this->showImage('airlines', $this->routes[$i]['airlineId'], 40, 40)?>"></a>
                                    </figure>
                                    <div class="action">
                                        <a href="<?php echo $this->url(array('flightId'=>$this->routes[$i]['id']), 'booking', true)?>" class="button"><?php echo $this->translate('BOOK')?></a>
                                    </div>
                                    <div class="details">
                                        <h5 class="box-title"><?php echo $this->routes[$i]['srcCity'] . ' ' . $this->translate('to') . ' ' . $this->routes[$i]['dstCity']?></h5>
                                        <label class="price-wrapper"><span class="price-per-unit"><?php echo $this->price($this->routes[$i]['price'])?></span><?php echo $this->translate('oneway')?></label>
                                    </div>
                                </div>
                                <?php endfor;?>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <h2><?php echo $this->translate('Get Travel Insurance')?></h2>
                            <div class="icon-box style7 border-bottom">
                                <i class="soap-icon-user yellow-bg"></i>
                                <div class="description">
                                    <h4 class="box-title"><a href="/"><?php echo $this->translate('Single Trip Plans')?></a></h4>
                                    <ul class="circle">
                                        <li><?php echo $this->translate('Trip Protector')?></li>
                                        <li><?php echo $this->translate('Rental Car Damage Protector')?></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="icon-box style7">
                                <i class="soap-icon-friends yellow-bg"></i>
                                <div class="description">
                                    <h4 class="box-title"><a href="/"><?php echo $this->translate('Multi-Trip (Annual) Plans')?></a></h4>
                                    <ul class="circle">
                                        <li><?php echo $this->translate('Best value for frequent travelers')?></li>
                                        <li><?php echo $this->translate('Coverage for non-award')?></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        
<?php $this->inlineScript()->appendScript('
	tjq(document).ready(function() {
        tjq( ".autocomplete" ).autocomplete({
            source: "/ajax/get-city",
            minLength: 2
        });
    });');?>