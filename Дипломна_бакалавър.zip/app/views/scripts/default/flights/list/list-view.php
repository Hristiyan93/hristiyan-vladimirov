<div class="flight-list listing-style3 flight">
    <?php echo $this->partialLoop('default/flights/list/list-view-item.php', $this->items)?>
</div>