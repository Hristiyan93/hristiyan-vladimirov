<div class="row flight-list image-box flight listing-style1">
    <?php echo $this->partialLoop('default/flights/list/grid-view-item.php', $this->items)?>
</div>