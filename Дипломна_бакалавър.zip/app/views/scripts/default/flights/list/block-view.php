<div class="flight-list row image-box listing-style2 flight">
	<?php echo $this->partialLoop('default/flights/list/block-view-item.php', $this->items)?>
</div>