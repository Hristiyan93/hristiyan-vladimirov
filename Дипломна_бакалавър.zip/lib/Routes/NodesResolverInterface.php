<?php

interface Routes_NodesResolverInterface
{
    function getNeighbor(Routes_NodeInterface $node);
}
