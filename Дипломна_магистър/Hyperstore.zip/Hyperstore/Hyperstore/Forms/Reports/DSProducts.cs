﻿namespace HyperStoreApp.Forms.Reports
{


    partial class DSProducts
    {
    }
}

namespace HyperStoreApp.Forms.Reports.DSProductsTableAdapters {
    
    
    public partial class DepartmentsTableAdapter {
    }
}
